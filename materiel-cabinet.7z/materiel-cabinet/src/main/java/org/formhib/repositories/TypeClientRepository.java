package org.formhib.repositories;

import org.formhib.models.TypeClient;

public class TypeClientRepository extends GeneralRepository<TypeClient>{
}
