package org.formhib.repositories;

import org.formhib.models.Categorie;

public class CategorieRepository extends GeneralRepository<Categorie>{
}
