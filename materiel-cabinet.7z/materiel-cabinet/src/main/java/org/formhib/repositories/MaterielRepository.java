package org.formhib.repositories;

import org.formhib.models.Materiel;

public class MaterielRepository extends GeneralRepository<Materiel>{
}
