package org.formhib.repositories;

import org.formhib.models.FicheLocation;

public class FicheLocationRepository extends GeneralRepository<FicheLocation>{
}
