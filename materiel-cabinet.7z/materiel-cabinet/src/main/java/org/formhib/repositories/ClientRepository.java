package org.formhib.repositories;

import org.formhib.models.Client;

public class ClientRepository extends GeneralRepository<Client>{
}
