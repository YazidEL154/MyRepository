package org.formhib;

import org.formhib.models.*;
import org.formhib.repositories.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class App {
    public static void main(String[] args) throws ParseException {
        System.out.println("Bonjour Bonjour !");
        //SessionHibernate.currentSession();
        //SessionHibernate.currentSession();
        //SessionHibernate.closeSession();

        /*TypeClient tc = new TypeClient();
        TypeClientRepository tcr = new TypeClientRepository();
        tc.setLibelle("Professionnel");
        tcr.save(tc);*/

        /*Client c = new Client();
        ClientRepository cr = new ClientRepository();
        c.setNom("toto");
        c.setAdresse("15 rue de lens, 59300 Valenciennes");
        c.setNumero_tel("0700000000");
        tc = tcr.get(2,TypeClient.class);
        c.setType(tc);
        cr.save(c);*/

        /*Categorie ct = new Categorie();
        CategorieRepository ctr = new CategorieRepository();
        ct.setCode_categorie("OI");
        ct.setLibelle("Outillage industriel");
        ctr.save(ct);
        ct.setCode_categorie("MB");
        ct.setLibelle("Matériel de Bureau");
        ctr.save(ct);
        ct.setCode_categorie("MI");
        ct.setLibelle("Matériel Industriel");
        ctr.save(ct);*/

        /*Materiel m = new Materiel();
        MaterielRepository mr = new MaterielRepository();
        m.setDesignation("design 1");
        String sDate1="25/12/2020";
        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
        m.setDate_achat(date1);
        m.setPrix_jour(15.16);
        ct = ctr.get(1,Categorie.class);
        m.setCategorie(ct);
        mr.save(m);

        m.setDesignation("design 2");
        String sDate2="20/05/2020";
        Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
        m.setDate_achat(date2);
        m.setPrix_jour(35.16);
        ct = ctr.get(2,Categorie.class);
        m.setCategorie(ct);
        mr.save(m);

        m.setDesignation("design 3");
        String sDate3="20/05/2020";
        Date date3=new SimpleDateFormat("dd/MM/yyyy").parse(sDate3);
        m.setDate_achat(date3);
        m.setPrix_jour(20.16);
        ct = ctr.get(3,Categorie.class);
        m.setCategorie(ct);
        mr.save(m);*/

        MaterielRepository mr = new MaterielRepository();

        Materiel m = mr.get(3, Materiel.class);
        //List<Client> clients = new ArrayList<>();
        //ClientRepository cr = new ClientRepository();
        //clients.add(cr.get(1, Client.class));
        //clients.add(cr.get(2, Client.class));
        System.out.println(m.getDesignation());

        /*FicheLocation f = new FicheLocation();
        FicheLocationRepository fr = new FicheLocationRepository();
        f = fr.get(1, FicheLocation.class);
        String sDate1="25/12/2020";
        Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
        f.setDate_location(date1);
        fr.update(f);
        f = fr.get(3, FicheLocation.class);
        String sDate3="20/05/2020";
        Date date3=new SimpleDateFormat("dd/MM/yyyy").parse(sDate3);
        f.setDate_location(date3);
        fr.update(f);*/


    }
}
