package org.formhib.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


import java.util.Date;

public class SessionHibernate {
    public static final ThreadLocal<Session> threadSession = new ThreadLocal<>();
    public static SessionFactory sessionFactory;
    private static StandardServiceRegistry serviceRegistry;

    static {
        try {
            System.out.println(new Date() + " : Initialisation ...");
            Configuration configuration = new Configuration().configure();
            serviceRegistry = new StandardServiceRegistryBuilder().configure().build();
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * Permet de recuperer ma session
     * @return {Session}
     */
    public static Session currentSession()  {
        Session session = (Session) threadSession.get();
        if (session == null) {
            System.out.println("J'ouvre une nouvelle session");
            session = sessionFactory.openSession();
            System.out.println("J'injecte ma session dans mon Thread");
            threadSession.set(session);
        }
        System.out.println("Je récupère ma session");
        return session;
    }

    /**
     * Permet de fermer ma session
     */
    public static void closeSession() {
        Session session = (Session) threadSession.get();
        if (session != null) session.close();
        threadSession.set(null);
        System.out.println("Fermeture de ma session");
    }

}
