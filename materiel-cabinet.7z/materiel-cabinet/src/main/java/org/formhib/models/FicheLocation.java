package org.formhib.models;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "fiche_location", schema = "materiel_cabinet")
public class FicheLocation {

    private int numero_location;
    //private Client client;
    //private Materiel materiel;
    private Date date_location;

    @Id
    @Column(name = "numero_location", nullable = false)
    public int getNumero_location() {
        return numero_location;
    }
    public void setNumero_location(int numero_location) {
        this.numero_location = numero_location;
    }

    @Basic
    @Column(name = "date_location", nullable = true)
    public Date getDate_location() {
        return date_location;
    }
    public void setDate_location(Date date_location) {
        this.date_location = date_location;
    }




}
