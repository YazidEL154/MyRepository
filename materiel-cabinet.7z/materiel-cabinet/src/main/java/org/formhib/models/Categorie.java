package org.formhib.models;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "categorie", schema = "materiel_cabinet")
public class Categorie {

    private int id_categorie;
    private String code_categorie;
    private String libelle;
    private List<Materiel> materiels;


    @Id
    @Column(name = "id_categorie", nullable = false)
    public int getId_categorie() {
        return id_categorie;
    }

    @Basic
    @Column(name = "code_categorie", nullable = true, length = 255)
    public String getCode_categorie() {
        return code_categorie;
    }

    @Basic
    @Column(name = "libelle", nullable = true, length = 255)
    public String getLibelle() {
        return libelle;
    }

    @OneToMany(mappedBy = "categorie", fetch = FetchType.EAGER)
    public List<Materiel> getMateriels() {
        return materiels;
    }

    public void setId_categorie(int id_categorie) {
        this.id_categorie = id_categorie;
    }

    public void setCode_categorie(String code_categorie) {
        this.code_categorie = code_categorie;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setMateriels(List<Materiel> materiels) {
        this.materiels = materiels;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_categorie, code_categorie, libelle);
    }
}
