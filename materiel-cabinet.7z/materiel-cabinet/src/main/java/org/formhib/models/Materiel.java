package org.formhib.models;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "materiel", schema = "materiel_cabinet")
public class Materiel {

    private int ref_materiel;
    private String designation;
    private Date date_achat;
    private double prix_jour;
    private Categorie categorie;


    private List<Client> clients;


    @Id
    @Column(name = "ref_materiel", nullable = false)
    public int getRef_materiel() {
        return ref_materiel;
    }

    @Basic
    @Column(name = "designation", nullable = true, length = 255)
    public String getDesignation() {
        return designation;
    }

    @Basic
    @Column(name = "date_achat", nullable = true)
    public Date getDate_achat() {
        return date_achat;
    }

    @Basic
    @Column(name = "prix_jour", nullable = true)
    public double getPrix_jour() {
        return prix_jour;
    }

    @ManyToOne
    @JoinColumn(name = "id_categorie")
    public Categorie getCategorie() {
        return categorie;
    }


    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    public List<Client> getClients() {
        return clients;
    }

    public void setRef_materiel(int ref_materiel) {
        this.ref_materiel = ref_materiel;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setDate_achat(Date date_achat) {
        this.date_achat = date_achat;
    }

    public void setPrix_jour(double prix_jour) {
        this.prix_jour = prix_jour;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public void setClients(List<Client> clients) {
        this.clients = clients;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ref_materiel, designation, date_achat, prix_jour, categorie);
    }




}
