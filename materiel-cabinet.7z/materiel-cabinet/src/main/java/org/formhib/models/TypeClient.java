package org.formhib.models;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "type_client", schema = "materiel_cabinet")
public class TypeClient {


    private int id_type;
    private String libelle;
    private List<Client> clients;

    @Id
    @Column(name = "id_type", nullable = false)
    public int getId_type() {
        return id_type;
    }
    public void setId_type(int id_type) {
        this.id_type = id_type;
    }

    @Basic
    @Column(name = "libelle", nullable = true, length = 255)
    public String getLibelle() {
        return libelle;
    }
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    @OneToMany(mappedBy = "type", fetch = FetchType.EAGER)
    public List<Client> getClients() {
        return clients;
    }
    public void setClients(List<Client> clients) {
        this.clients = clients;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_type, libelle);
    }
}
