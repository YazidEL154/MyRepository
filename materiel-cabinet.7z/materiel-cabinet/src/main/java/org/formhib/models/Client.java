package org.formhib.models;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "client", schema = "materiel_cabinet")
public class Client {

    private int code_client;
    private String nom;
    private String adresse;
    private String numero_tel;
    private TypeClient type;
    private List<Materiel> materiels;

    @Id
    @Column(name = "code_client", nullable = false)
    public int getCode_client() {
        return code_client;
    }
    public void setCode_client(int code_client) {
        this.code_client = code_client;
    }

    @Basic
    @Column(name = "nom", nullable = true, length = 255)
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    @Basic
    @Column(name = "adresse", nullable = true, length = 255)
    public String getAdresse() {
        return adresse;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    @Basic
    @Column(name = "numero_tel", nullable = true, length = 255)
    public String getNumero_tel() {
        return numero_tel;
    }
    public void setNumero_tel(String numero_tel) {
        this.numero_tel = numero_tel;
    }

    @ManyToOne
    @JoinColumn(name = "id_type")
    public TypeClient getType() {
        return type;
    }
    public void setType(TypeClient type) {
        this.type = type;
    }

    @ManyToMany(mappedBy = "clients")
    public List<Materiel> getMateriels() {
        return materiels;
    }
    public void setMateriels(List<Materiel> materiels) {
        this.materiels = materiels;
    }

    @Override
    public int hashCode() {
        return Objects.hash(code_client, nom, adresse, numero_tel, type);
    }


}
